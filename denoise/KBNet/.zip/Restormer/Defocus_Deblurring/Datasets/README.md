For training and testing, your directory structure should look like this
  
 `Datasets` <br/>
 `├──train`  <br/>
     `└──DPDD`   <br/>
          `├──inputL_crops`   <br/>
          `├──inputR_crops`   <br/>
          `├──inputC_crops`   <br/>
          `└──target_crops`   <br/>
 `├──val`  <br/>
     `└──DPDD`   <br/>
          `├──inputL_crops`   <br/>
          `├──inputR_crops`   <br/>
          `├──inputC_crops`   <br/>
          `└──target_crops`   <br/>
 `└──test`  <br/>
     `└──DPDD`   <br/>
          `├──inputL`   <br/>
          `├──inputR`   <br/>
          `├──inputC`   <br/>
          `└──target`
          